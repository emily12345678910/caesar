#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    int errors = 0;

    // Check if program has command-line argument
    if (argc != 2)
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }

    // Check that all characters of argument is a digit
    else
        for (int i = 0, n = strlen(argv[1]); i < n; i++)
        {
            if (isalpha(argv[1][i]))
            {
                printf("Usage: ./caesar key\n");
                errors = 1;
            }
        }

    // Convert argument from a string to an int
    string K = argv[1];
    int B = atoi(K);

    // Prompt user for plaintext
    string plain = get_string("plaintext: ");

    // If no errors, print success
    if (errors == 0)
    {
        printf("ciphertext: ");
    }
    
    // Isolate every character of the plaintext string
    char *p = plain;
    int length = (int)strlen(plain);
    for (int i = 0; i < length; i++)
    
        // If uppercase, rotate it, preserve case, print out the rotated character
        if (isupper(p[i]))
        {
            printf("%c", (toupper(((p[i] - 65) + B) % 26) + 65));
        }
    
    // If lowercase, rotate it, preserve case, print out the rotated character
        else if (islower(p[i]))
        {
            printf("%c", (tolower(((p[i] - 97) + B) % 26) + 97));
        }
    
    // If it is neither, print out the character as is
        else if (ispunct(p[i]))
        {
            printf("%c", (plain[i]));
        }
        else if (isspace(p[i]))
        {
            printf("%c", (plain[i]));
        }
    
    // Print a newline
    printf("\n");
}




